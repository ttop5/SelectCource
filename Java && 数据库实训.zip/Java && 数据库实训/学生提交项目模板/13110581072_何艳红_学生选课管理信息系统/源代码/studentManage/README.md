# studentManage

---

Java和数据库实训项目(请自动忽略studentManage这个文不对题的项目名称)。


### 题目要求:

- **学生选课管理信息系统**
    
    > + 学院信息维护
    > + 教师信息维护
    > + 学生信息维护
    > + 教室信息
    > + 选课信息
    > + 成绩信息
    > + 按一定条件可以查询所有信息



### 开发环境：

+ Java7 + Tomcat7 + Mysql 5.6.25

+ Ubuntu 15.04 + Vim + Intellij IDEA + Git
